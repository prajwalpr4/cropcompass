import IrrigationPlan from "@/components/irrigation-plan";

export default function IrrigationPlanPage() {
    return <IrrigationPlan />;
}
