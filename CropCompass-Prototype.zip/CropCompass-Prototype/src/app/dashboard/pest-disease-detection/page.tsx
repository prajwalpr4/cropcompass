import PestDiseaseDetection from "@/components/pest-disease-detection";

export default function PestDiseaseDetectionPage() {
    return <PestDiseaseDetection />;
}
