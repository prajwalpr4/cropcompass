import Inventory from "@/components/inventory";

export default function InventoryPage() {
    return <Inventory />;
}
