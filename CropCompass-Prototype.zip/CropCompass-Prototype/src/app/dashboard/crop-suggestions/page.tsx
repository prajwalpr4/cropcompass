import CropSuggestion from "@/components/crop-suggestion";

export default function CropSuggestionsPage() {
    return <CropSuggestion />;
}
