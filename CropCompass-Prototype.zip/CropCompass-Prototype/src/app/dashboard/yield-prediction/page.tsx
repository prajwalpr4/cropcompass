import YieldPrediction from "@/components/yield-prediction";

export default function YieldPredictionPage() {
    return <YieldPrediction />;
}
