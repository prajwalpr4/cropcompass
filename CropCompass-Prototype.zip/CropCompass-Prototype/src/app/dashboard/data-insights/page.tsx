import AiInsights from "@/components/ai-insights";

export default function DataInsightsPage() {
    return <AiInsights />;
}
