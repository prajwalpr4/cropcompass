import GovtSchemes from "@/components/govt-schemes";

export default function GovtSchemesPage() {
    return <GovtSchemes />;
}
