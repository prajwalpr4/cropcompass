
import CropDistribution from "@/components/crop-distribution";

export default function CropDistributionPage() {
    return <CropDistribution />;
}
