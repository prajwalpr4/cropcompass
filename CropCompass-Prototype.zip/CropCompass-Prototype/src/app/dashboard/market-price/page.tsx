import MarketPrice from "@/components/market-price";

export default function MarketPricePage() {
    return <MarketPrice />;
}
